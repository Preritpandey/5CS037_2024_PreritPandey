public class Qno1{
    public static void main(String[] args) {
        String data ="i am data";
        System.out.println('"'+data+'"');
        }
}