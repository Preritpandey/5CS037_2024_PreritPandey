import java.util.Scanner;

public class Qno10 {
    public static void main(String[] args) {
    Scanner inp=new Scanner(System.in);
    int a = inp.nextInt();
    int b = inp.nextInt();
    System.out.println(a*b);
    inp.close();
    }
}
