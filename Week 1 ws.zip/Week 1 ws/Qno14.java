import java.util.Scanner;

public class Qno14 {
    public static void main(String[] args) {
    Scanner inp=new Scanner(System.in);
    int us = inp.nextInt();
    double npr =us*134;
    System.out.println(npr);
    inp.close();
    }
}
