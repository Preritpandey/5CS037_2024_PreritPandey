public class Qno3 {
    public static void main(String[] args) {
        int a=10;
        double b=12.212;
        char c= 's';
        System.out.println("this is int"+a+"\n"+"this is double"+b+"\n"+"this is char "+c);
        }
}
