public class Qno4 {
    public static void main(String[] args) {
        int a=10;
        int b=20;
        int c=20;
        int s=(a+b+c)/2;
        float a2=s*(s-a)*(s-b)*(s-c);
        System.out.println("this area is "+Math.sqrt(a2));
        }
}
