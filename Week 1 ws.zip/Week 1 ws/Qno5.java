import java.util.Scanner;
public class Qno5 {
   public static void main(String[] args) {
    Scanner inp=new Scanner(System.in);
    double length = inp.nextDouble();
    double area= length * length;
    System.out.println(area);
    inp.close();
   }
    
}
