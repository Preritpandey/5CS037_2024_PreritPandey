import java.util.Scanner;

public class Qno9 {
    public static void main(String[] args) {
    Scanner inp=new Scanner(System.in);
    int a = inp.nextInt();
    int b = inp.nextInt();
       
        System.out.println("this is addition :"+ a+b);                                                                                      
        System.out.println("this is sub :"+ (a-b));                                                                                      
        System.out.println("this is mul :"+(a*b));                                                                                      
        System.out.println("this is div :"+(a/2));
        inp.close();

    }
}
